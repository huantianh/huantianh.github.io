"""ENGR 1105 Week 4 - Python sensor-data demo.
Run in Google Colab or a local Python environment.
"""
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

data_file = Path(__file__).with_name("sample_sensor_data.csv")
df = pd.read_csv(data_file)

valid = (df["raw_distance_cm"] > 1) & (df["raw_distance_cm"] < 400)
df_valid = df.loc[valid].copy()

df_valid["filtered_cm"] = (
    df_valid["raw_distance_cm"]
    .rolling(3, center=True, min_periods=1)
    .mean()
)

m, b = np.polyfit(
    df_valid["raw_distance_cm"],
    df_valid["reference_distance_cm"],
    1,
)
df_valid["calibrated_cm"] = m * df_valid["raw_distance_cm"] + b

df_valid["raw_error_cm"] = (
    df_valid["raw_distance_cm"] - df_valid["reference_distance_cm"]
)
df_valid["cal_error_cm"] = (
    df_valid["calibrated_cm"] - df_valid["reference_distance_cm"]
)
mae_raw = np.mean(np.abs(df_valid["raw_error_cm"]))
mae_cal = np.mean(np.abs(df_valid["cal_error_cm"]))

def classify(distance_cm):
    if distance_cm < 15:
        return "DANGER"
    if distance_cm < 35:
        return "WARNING"
    return "SAFE"

df_valid["state"] = df_valid["filtered_cm"].apply(classify)

print(df_valid.round(2))
print(f"Calibration: reference = {m:.3f}*raw + {b:.3f}")
print(f"Raw MAE: {mae_raw:.3f} cm")
print(f"Calibrated MAE: {mae_cal:.3f} cm")

plt.figure(figsize=(8, 4.5))
plt.plot(df_valid["time_s"], df_valid["raw_distance_cm"], "o-", label="Raw")
plt.plot(df_valid["time_s"], df_valid["filtered_cm"], "-", label="Filtered")
plt.plot(
    df_valid["time_s"],
    df_valid["reference_distance_cm"],
    "--",
    label="Reference",
)
plt.xlabel("Time (s)")
plt.ylabel("Distance (cm)")
plt.title("Ultrasonic Sensor Data")
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()
