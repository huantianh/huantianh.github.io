// ============================================================
// ENGR 3303 - Controls Engineering
// Week 6 Lab - Final Filtered PI Motor-Speed Controller
//
// Output columns:
// time_s,reference_rpm,raw_rpm,filtered_rpm,error_rpm,pwm,integral
// ============================================================

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;

const int ENC_A = 2;
const int ENC_B = 3;

volatile long encoderCount = 0;

// Replace with instructor-verified value.
const float COUNTS_PER_OUTPUT_REV = 234.3;

// ------------------------------------------------------------
// FINAL CONTROLLER SETTINGS
// Replace with your team's selected values.
// ------------------------------------------------------------
const float REFERENCE_RPM = 120.0;
const float KP = 3.0;
const float KI = 0.2;

const unsigned long SAMPLE_MS = 100;
const float TS = SAMPLE_MS / 1000.0;

const float FILTER_ALPHA = 0.7;

const float INTEGRAL_MIN = -100.0;
const float INTEGRAL_MAX = 100.0;

// Experiment timing
const unsigned long START_DELAY_MS = 2000;
const unsigned long RUN_TIME_MS = 10000;

unsigned long experimentStart = 0;
unsigned long lastSample = 0;

bool controllerEnabled = false;
bool experimentFinished = false;
bool filterInitialized = false;

float integral = 0.0;
float filteredRPM = 0.0;

void countEncoder() {
  encoderCount++;
}

void setMotorPWM(int pwm) {
  pwm = constrain(pwm, 0, 255);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, pwm);
}

void stopMotor() {
  analogWrite(ENA, 0);
}

void setup() {
  Serial.begin(115200);

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(ENC_A),
    countEncoder,
    RISING
  );

  stopMotor();

  experimentStart = millis();
  lastSample = experimentStart;

  Serial.println("START");
  Serial.println("time_s,reference_rpm,raw_rpm,filtered_rpm,error_rpm,pwm,integral");
}

void loop() {

  if (experimentFinished) {
    return;
  }

  unsigned long now = millis();
  unsigned long elapsed = now - experimentStart;

  if (!controllerEnabled && elapsed >= START_DELAY_MS) {
    controllerEnabled = true;
    integral = 0.0;
    filterInitialized = false;
  }

  if (now - lastSample >= SAMPLE_MS) {

    float dt = (now - lastSample) / 1000.0;

    noInterrupts();
    long counts = encoderCount;
    encoderCount = 0;
    interrupts();

    float countsPerSecond = counts / dt;
    float rawRPM =
      countsPerSecond * 60.0 / COUNTS_PER_OUTPUT_REV;

    if (!filterInitialized) {
      filteredRPM = rawRPM;
      filterInitialized = true;
    } else {
      filteredRPM =
        FILTER_ALPHA * rawRPM +
        (1.0 - FILTER_ALPHA) * filteredRPM;
    }

    float referenceRPM = 0.0;
    float errorRPM = 0.0;
    int pwmCommand = 0;

    if (controllerEnabled) {

      referenceRPM = REFERENCE_RPM;
      errorRPM = referenceRPM - filteredRPM;

      integral += errorRPM * TS;
      integral = constrain(
        integral,
        INTEGRAL_MIN,
        INTEGRAL_MAX
      );

      float control =
        KP * errorRPM +
        KI * integral;

      control = constrain(control, 0.0, 255.0);

      pwmCommand = (int)(control + 0.5);

      setMotorPWM(pwmCommand);

    } else {

      stopMotor();
      integral = 0.0;
    }

    float timeSeconds = elapsed / 1000.0;

    Serial.print(timeSeconds, 3);
    Serial.print(",");
    Serial.print(referenceRPM, 2);
    Serial.print(",");
    Serial.print(rawRPM, 2);
    Serial.print(",");
    Serial.print(filteredRPM, 2);
    Serial.print(",");
    Serial.print(errorRPM, 2);
    Serial.print(",");
    Serial.print(pwmCommand);
    Serial.print(",");
    Serial.println(integral, 3);

    lastSample = now;
  }

  if (elapsed >= START_DELAY_MS + RUN_TIME_MS) {

    stopMotor();
    Serial.println("END");
    experimentFinished = true;
  }
}
