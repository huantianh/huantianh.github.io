"""
ENGR 3303 - Week 6 Lab
Compare final controller performance at several reference speeds.

Requires:
    pip install pandas numpy matplotlib
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------- USER SETTINGS ----------------
files = [
    "final_ref80.csv",
    "final_ref120.csv",
    "final_ref150.csv",
]

labels = [
    "80 RPM test",
    "120 RPM test",
    "150 RPM test",
]
# ------------------------------------------------

summary = []

plt.figure()

for filename, label in zip(files, labels):

    df = pd.read_csv(filename)

    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()

    t = d["Time_s"].to_numpy()
    t = t - t[0]

    ref = d["Reference_RPM"].to_numpy()
    rpm = d["Filtered_RPM"].to_numpy()
    pwm = d["PWM"].to_numpy()

    R = np.mean(ref)
    yss = np.mean(rpm[-min(15, len(rpm)):])
    ess = R - yss
    ymax = np.max(rpm)
    overshoot = max(0.0, ymax - R)
    max_pwm = np.max(pwm)

    summary.append({
        "Test": label,
        "ReferenceRPM": R,
        "FinalRPM": yss,
        "ErrorRPM": ess,
        "OvershootRPM": overshoot,
        "MaxPWM": max_pwm,
    })

    plt.plot(t, rpm, linewidth=1.6, label=f"{R:.0f} RPM reference")

plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("Filtered Motor Speed (RPM)")
plt.title("Final Controller at Multiple Reference Speeds")
plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
plt.tight_layout()
plt.savefig("week6_reference_comparison.png", dpi=200, bbox_inches="tight")

summary_df = pd.DataFrame(summary)
print(summary_df)
summary_df.to_csv("week6_reference_summary.csv", index=False)

plt.show()
