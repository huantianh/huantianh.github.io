"""
ENGR 3303 - Week 6
First-order motor frequency-response visualization.

Requires:
    pip install numpy matplotlib
"""

import numpy as np
import matplotlib.pyplot as plt

# ---------------- USER SETTINGS ----------------
K = 0.775       # Week 2 steady-state gain, RPM/PWM
tau = 0.55      # Week 2 time constant, s
# ------------------------------------------------

w = np.logspace(-2, 2, 500)   # rad/s

G = K / (1 + 1j * w * tau)

mag_db = 20 * np.log10(np.abs(G))
phase_deg = np.angle(G, deg=True)

wc = 1.0 / tau
fc = wc / (2 * np.pi)

print(f"Corner frequency wc = {wc:.3f} rad/s")
print(f"Corner frequency fc = {fc:.3f} Hz")

plt.figure()
plt.semilogx(w, mag_db, linewidth=2)
plt.axvline(wc, linestyle="--", label=f"corner = {wc:.2f} rad/s")
plt.grid(True, which="both")
plt.xlabel("Angular Frequency (rad/s)")
plt.ylabel("Magnitude (dB)")
plt.title("First-Order Motor Frequency Response - Magnitude")
plt.legend(loc="best")
plt.tight_layout()
plt.savefig("week6_bode_magnitude.png", dpi=200)

plt.figure()
plt.semilogx(w, phase_deg, linewidth=2)
plt.axvline(wc, linestyle="--", label=f"corner = {wc:.2f} rad/s")
plt.grid(True, which="both")
plt.xlabel("Angular Frequency (rad/s)")
plt.ylabel("Phase (deg)")
plt.title("First-Order Motor Frequency Response - Phase")
plt.legend(loc="best")
plt.tight_layout()
plt.savefig("week6_bode_phase.png", dpi=200)

plt.show()
