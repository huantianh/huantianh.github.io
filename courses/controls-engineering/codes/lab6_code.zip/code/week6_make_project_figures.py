"""
ENGR 3303 - Week 6
Create clean project figures from earlier course CSV files.

The filenames below are examples. Change them to match your team's files.

Requires:
    pip install pandas matplotlib
"""

from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


# ---------------- USER SETTINGS ----------------
P_FILE = "P_Kp3.csv"
PI_FILE = "PI_Ki0p2.csv"
FINAL_FILE = "final_ref120.csv"
# ------------------------------------------------


def get_time_and_speed(filename):
    df = pd.read_csv(filename)

    if "Reference_RPM" not in df.columns:
        raise ValueError(f"{filename}: missing Reference_RPM column")

    if "Filtered_RPM" in df.columns:
        speed_col = "Filtered_RPM"
    elif "RPM" in df.columns:
        speed_col = "RPM"
    else:
        raise ValueError(f"{filename}: no RPM or Filtered_RPM column")

    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()

    if d.empty:
        raise ValueError(f"{filename}: no data after reference step")

    t = d["Time_s"].to_numpy()
    t = t - t[0]

    speed = d[speed_col].to_numpy()
    ref = d["Reference_RPM"].to_numpy()

    return t, speed, ref


def make_figure(filename, title, output_png):

    if not Path(filename).exists():
        print(f"Skipping {filename}: file not found")
        return

    t, speed, ref = get_time_and_speed(filename)

    plt.figure()
    plt.plot(t, ref, "--", linewidth=1.5, label="Reference")
    plt.plot(t, speed, linewidth=1.8, label="Measured speed")
    plt.grid(True)
    plt.xlabel("Time After Reference Step (s)")
    plt.ylabel("Motor Speed (RPM)")
    plt.title(title)
    plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
    plt.tight_layout()
    plt.savefig(output_png, dpi=200, bbox_inches="tight")
    plt.close()

    print(f"Saved {output_png}")


make_figure(
    P_FILE,
    "Week 3 - Proportional Control",
    "project_figure_p_control.png"
)

make_figure(
    PI_FILE,
    "Week 4 - PI Control",
    "project_figure_pi_control.png"
)

make_figure(
    FINAL_FILE,
    "Final Filtered PI Controller",
    "project_figure_final_control.png"
)
