"""
ENGR 3303 - Week 2 Lab
Estimate K and tau from a motor step-response CSV.

Install packages:
    pip install pandas numpy matplotlib
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

TRIAL_NUMBER = 1
FILENAME = f"motor_step_trial{TRIAL_NUMBER}.csv"
PWM_STEP = 180
STEP_TIME = 2.0
N_AVG = 10

df = pd.read_csv(FILENAME)
t = df["Time_s"].to_numpy()
rpm = df["RPM"].to_numpy()

mask = t >= STEP_TIME
t_exp = t[mask] - STEP_TIME
rpm_exp = rpm[mask]

baseline = np.mean(rpm[t < STEP_TIME]) if np.any(t < STEP_TIME) else 0.0
rpm_adj = rpm_exp - baseline

N = min(N_AVG, len(rpm_adj))
yss = np.mean(rpm_adj[-N:])
K = yss / PWM_STEP

target = 0.632 * yss
idx_tau = np.argmin(np.abs(rpm_adj - target))
tau = t_exp[idx_tau]

rpm_model = K * PWM_STEP * (1 - np.exp(-t_exp / tau))

print(f"Baseline speed      = {baseline:.2f} RPM")
print(f"Steady-state speed  = {yss:.2f} RPM")
print(f"K                   = {K:.4f} RPM/PWM")
print(f"tau                 = {tau:.3f} s")
print(f"G(s) = {K:.4f} / ({tau:.3f} s + 1)")

plt.plot(t_exp, rpm_adj, "o", markersize=4, label="Measured")
plt.plot(t_exp, rpm_model, linewidth=2, label="First-order model")
plt.grid(True)
plt.xlabel("Time After Step (s)")
plt.ylabel("Motor Speed Change (RPM)")
plt.title("Measured vs. First-Order Motor Model")
plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
plt.tight_layout()
plt.show()
