"""
ENGR 3303 - Week 2 Lab
Record motor step-response data from Arduino and save CSV.

Install packages:
    pip install pyserial pandas matplotlib
"""
import time
import pandas as pd
import matplotlib.pyplot as plt
import serial

PORT = "COM3"          # Change to your Arduino port
BAUD = 115200
FILENAME = "motor_step_trial1.csv"

rows = []

with serial.Serial(PORT, BAUD, timeout=3) as ser:
    time.sleep(2.0)
    ser.reset_input_buffer()
    print("Connected. Sending START...")
    ser.write(b"START\n")

    while True:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue
        if line == "START":
            print("Arduino started.")
            continue
        if line == "END":
            print("Arduino finished.")
            break
        if "time" in line.lower():
            continue
        parts = line.split(",")
        if len(parts) == 2:
            try:
                t, rpm = float(parts[0]), float(parts[1])
            except ValueError:
                continue
            rows.append({"Time_s": t, "RPM": rpm})
            print(f"t={t:6.3f} s, RPM={rpm:8.2f}")

df = pd.DataFrame(rows)
df.to_csv(FILENAME, index=False)
print(f"Saved {FILENAME}")

plt.plot(df["Time_s"], df["RPM"], "o-", linewidth=1.2, markersize=4)
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("Motor Speed (RPM)")
plt.title("Measured DC Motor Step Response")
plt.tight_layout()
plt.show()
