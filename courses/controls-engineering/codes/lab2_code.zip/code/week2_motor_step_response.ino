// ============================================================
// ENGR 3303 - Controls Engineering
// Week 2 Lab - Motor Step Response Data Acquisition
// ============================================================
// Wiring:
//   D9 -> L298N ENA
//   D7 -> L298N IN1
//   D8 -> L298N IN2
//   D2 -> Encoder A (yellow)
//   D3 -> Encoder B (green)
//   5V -> Encoder + (blue)
//   GND -> Encoder - (black) and L298N GND
//
// Python sends START. Arduino waits 2 seconds, applies a PWM
// step, reports time_s,rpm every 100 ms, and stops automatically.
// ============================================================

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;

const int ENC_A = 2;
const int ENC_B = 3;

volatile long encoderCount = 0;

// Replace with instructor-verified calibration if different.
// This value assumes Encoder-A rising edges only.
const float COUNTS_PER_OUTPUT_REV = 234.3;

// PWM step used in the experiment.
const int STEP_PWM = 180;

const unsigned long SAMPLE_MS = 100;       // 10 Hz
const unsigned long STEP_DELAY_MS = 2000;  // motor off for first 2 s
const unsigned long TOTAL_MS = 10000;      // total experiment = 10 s

bool experimentRunning = false;
bool stepApplied = false;

unsigned long experimentStart = 0;
unsigned long lastSample = 0;

void countEncoderA() {
  encoderCount++;
}

void motorStop() {
  analogWrite(ENA, 0);
}

void startExperiment() {
  noInterrupts();
  encoderCount = 0;
  interrupts();

  motorStop();
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  experimentStart = millis();
  lastSample = experimentStart;
  stepApplied = false;
  experimentRunning = true;

  Serial.println("time_s,rpm");
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(ENC_A),
    countEncoderA,
    RISING
  );

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  motorStop();

  Serial.println("READY");
}

void loop() {
  // Wait for Python to send START.
  if (!experimentRunning && Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    command.trim();

    if (command == "START") {
      startExperiment();
    }
  }

  if (!experimentRunning) {
    return;
  }

  unsigned long now = millis();
  unsigned long elapsed = now - experimentStart;

  // Apply the PWM step at t = 2 s.
  if (!stepApplied && elapsed >= STEP_DELAY_MS) {
    analogWrite(ENA, STEP_PWM);
    stepApplied = true;
  }

  // Sample encoder speed every 100 ms.
  if (now - lastSample >= SAMPLE_MS) {
    float dt = (now - lastSample) / 1000.0;

    noInterrupts();
    long counts = encoderCount;
    encoderCount = 0;
    interrupts();

    float countsPerSecond = counts / dt;
    float rpm = countsPerSecond * 60.0 / COUNTS_PER_OUTPUT_REV;
    float timeSeconds = elapsed / 1000.0;

    Serial.print(timeSeconds, 3);
    Serial.print(",");
    Serial.println(rpm, 2);

    lastSample = now;
  }

  // Automatic shutdown after 10 s total.
  if (elapsed >= TOTAL_MS) {
    motorStop();
    experimentRunning = false;
    stepApplied = false;
    Serial.println("END");
  }
}
