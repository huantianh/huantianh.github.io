"""
ENGR 3303 - Week 5 Lab
Compare filtered-controller tests.

Requires:
    pip install pandas numpy matplotlib
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------- USER SETTINGS ----------------
files = ["filter_alpha1.csv", "filter_alpha0p7.csv", "filter_alpha0p5.csv"]
labels = ["alpha = 1.0", "alpha = 0.7", "alpha = 0.5"]
# ------------------------------------------------

summary = []

plt.figure()
for fname, label in zip(files, labels):
    df = pd.read_csv(fname)
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()
    t = d["Time_s"].to_numpy()
    t = t - t[0]

    ref = d["Reference_RPM"].to_numpy()
    filt = d["Filtered_RPM"].to_numpy()
    pwm = d["PWM"].to_numpy()

    R = np.mean(ref)
    yss = np.mean(filt[-min(15, len(filt)):])
    ess = R - yss
    ymax = np.max(filt)
    overshoot = max(0.0, ymax - R)
    max_pwm = np.max(pwm)

    summary.append({
        "Test": label,
        "ReferenceRPM": R,
        "FinalRPM": yss,
        "ErrorRPM": ess,
        "OvershootRPM": overshoot,
        "MaxPWM": max_pwm
    })

    plt.plot(t, filt, linewidth=1.5, label=label)

plt.axhline(summary[0]["ReferenceRPM"], linestyle="--", label="Reference")
plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("Filtered RPM")
plt.title("Effect of RPM Filtering")
plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
plt.tight_layout()

summary_df = pd.DataFrame(summary)
print(summary_df)
summary_df.to_csv("filter_summary.csv", index=False)

plt.show()
