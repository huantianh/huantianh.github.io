// ============================================================
// ENGR 3303 - Controls Engineering
// Week 5 Lab - Filtered PI Motor-Speed Control
//
// Python sends START. Arduino waits 2 seconds, enables the
// controller, reports data, and stops automatically.
// Output columns:
// time_s,reference_rpm,raw_rpm,filtered_rpm,error_rpm,pwm,integral
// ============================================================

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;
const int ENC_A = 2;
const int ENC_B = 3;

volatile long encoderCount = 0;

// Experimentally calibrated course value.
// Valid for Encoder A, RISING edges only.
const float COUNTS_PER_OUTPUT_REV = 494.0;

// Controller settings. Use your Week 4 selected gains.
const float REFERENCE_RPM = 120.0;
const float KP = 3.0;
const float KI = 0.2;

const unsigned long SAMPLE_MS = 100;
const float TS = SAMPLE_MS / 1000.0;
const float FILTER_ALPHA = 0.7;

const unsigned long START_DELAY_MS = 2000;
const unsigned long RUN_TIME_MS = 10000;

const float INTEGRAL_MIN = -100.0;
const float INTEGRAL_MAX = 100.0;

unsigned long experimentStart = 0;
unsigned long lastSample = 0;
bool experimentRunning = false;
bool controllerEnabled = false;
bool filterInitialized = false;
float integral = 0.0;
float filteredRPM = 0.0;

void countEncoder() {
  encoderCount++;
}

void setMotorPWM(int pwm) {
  pwm = constrain(pwm, 0, 255);
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, pwm);
}

void stopMotor() {
  analogWrite(ENA, 0);
}

void startExperiment() {
  noInterrupts();
  encoderCount = 0;
  interrupts();

  stopMotor();
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  integral = 0.0;
  filteredRPM = 0.0;
  filterInitialized = false;
  controllerEnabled = false;
  experimentStart = millis();
  lastSample = experimentStart;
  experimentRunning = true;

  Serial.println("START");
  Serial.println("time_s,reference_rpm,raw_rpm,filtered_rpm,error_rpm,pwm,integral");
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENC_A), countEncoder, RISING);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  stopMotor();
  Serial.println("READY");
}

void loop() {
  if (!experimentRunning) {
    if (Serial.available() > 0) {
      String command = Serial.readStringUntil('\n');
      command.trim();
      if (command == "START") {
        startExperiment();
      }
    }
    return;
  }

  unsigned long now = millis();
  unsigned long elapsed = now - experimentStart;

  if (!controllerEnabled && elapsed >= START_DELAY_MS) {
    controllerEnabled = true;
    integral = 0.0;
    filterInitialized = false;
  }

  if (now - lastSample >= SAMPLE_MS) {
    float dt = (now - lastSample) / 1000.0;

    noInterrupts();
    long counts = encoderCount;
    encoderCount = 0;
    interrupts();

    float countsPerSecond = counts / dt;
    float rawRPM = countsPerSecond * 60.0 / COUNTS_PER_OUTPUT_REV;

    if (!filterInitialized) {
      filteredRPM = rawRPM;
      filterInitialized = true;
    } else {
      filteredRPM = FILTER_ALPHA * rawRPM +
                    (1.0 - FILTER_ALPHA) * filteredRPM;
    }

    float referenceRPM = 0.0;
    float errorRPM = 0.0;
    int pwmCommand = 0;

    if (controllerEnabled) {
      referenceRPM = REFERENCE_RPM;
      errorRPM = referenceRPM - filteredRPM;

      integral += errorRPM * TS;
      integral = constrain(integral, INTEGRAL_MIN, INTEGRAL_MAX);

      float control = KP * errorRPM + KI * integral;
      control = constrain(control, 0.0, 255.0);
      pwmCommand = (int)(control + 0.5);
      setMotorPWM(pwmCommand);
    } else {
      stopMotor();
      integral = 0.0;
    }

    float timeSeconds = elapsed / 1000.0;
    Serial.print(timeSeconds, 3);
    Serial.print(",");
    Serial.print(referenceRPM, 2);
    Serial.print(",");
    Serial.print(rawRPM, 2);
    Serial.print(",");
    Serial.print(filteredRPM, 2);
    Serial.print(",");
    Serial.print(errorRPM, 2);
    Serial.print(",");
    Serial.print(pwmCommand);
    Serial.print(",");
    Serial.println(integral, 3);

    lastSample = now;
  }

  if (elapsed >= START_DELAY_MS + RUN_TIME_MS) {
    stopMotor();
    experimentRunning = false;
    controllerEnabled = false;
    Serial.println("END");
  }
}
