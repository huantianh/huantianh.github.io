"""
ENGR 3303 - Week 5 Lab
Compare repeated final-controller trials.

Requires:
    pip install pandas numpy matplotlib
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

files = ["final_trial1.csv", "final_trial2.csv", "final_trial3.csv"]
labels = ["Trial 1", "Trial 2", "Trial 3"]

summary = []

plt.figure()
for fname, label in zip(files, labels):
    df = pd.read_csv(fname)
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()

    t = d["Time_s"].to_numpy()
    t = t - t[0]

    ref = d["Reference_RPM"].to_numpy()
    rpm = d["Filtered_RPM"].to_numpy()
    pwm = d["PWM"].to_numpy()

    R = np.mean(ref)
    yss = np.mean(rpm[-min(15, len(rpm)):])
    ess = R - yss
    ymax = np.max(rpm)
    overshoot = max(0.0, ymax - R)
    max_pwm = np.max(pwm)

    summary.append({
        "Trial": label,
        "ReferenceRPM": R,
        "FinalRPM": yss,
        "ErrorRPM": ess,
        "OvershootRPM": overshoot,
        "MaxPWM": max_pwm
    })

    plt.plot(t, rpm, linewidth=1.5, label=label)

plt.axhline(summary[0]["ReferenceRPM"], linestyle="--", label="Reference")
plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("Filtered RPM")
plt.title("Repeated Final-Controller Trials")
plt.legend()
plt.tight_layout()

summary_df = pd.DataFrame(summary)
print(summary_df)

avg_error = summary_df["ErrorRPM"].mean()
std_error = summary_df["ErrorRPM"].std()

print(f"\nAverage steady-state error = {avg_error:.2f} RPM")
print(f"Std. dev. of steady-state error = {std_error:.2f} RPM")

summary_df.to_csv("final_trial_summary.csv", index=False)

plt.show()
