// ============================================================
// ENGR 3303 - Controls Engineering
// Week 3 Lab - Proportional Motor-Speed Control
//
// Python sends START. Arduino waits 2 seconds, enables the
// controller, reports data, and stops automatically.
// Output columns:
// time_s,reference_rpm,rpm,error_rpm,pwm
// ============================================================

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;
const int ENC_A = 2;
const int ENC_B = 3;

volatile long encoderCount = 0;

// Experimentally calibrated course value.
// Valid for Encoder A, RISING edges only.
const float COUNTS_PER_OUTPUT_REV = 494.0;

const float REFERENCE_RPM = 120.0;
const float KP = 1.0;

const unsigned long SAMPLE_MS = 100;
const unsigned long START_DELAY_MS = 2000;
const unsigned long RUN_TIME_MS = 10000;

unsigned long experimentStart = 0;
unsigned long lastSample = 0;
bool experimentRunning = false;
bool controllerEnabled = false;

void countEncoder() {
  encoderCount++;
}

void setMotorPWM(int pwm) {
  pwm = constrain(pwm, 0, 255);
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  analogWrite(ENA, pwm);
}

void stopMotor() {
  analogWrite(ENA, 0);
}

void startExperiment() {
  noInterrupts();
  encoderCount = 0;
  interrupts();

  stopMotor();
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  experimentStart = millis();
  lastSample = experimentStart;
  controllerEnabled = false;
  experimentRunning = true;

  Serial.println("START");
  Serial.println("time_s,reference_rpm,rpm,error_rpm,pwm");
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(100);

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENC_A), countEncoder, RISING);

  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  stopMotor();
  Serial.println("READY");
}

void loop() {
  if (!experimentRunning) {
    if (Serial.available() > 0) {
      String command = Serial.readStringUntil('\n');
      command.trim();
      if (command == "START") {
        startExperiment();
      }
    }
    return;
  }

  unsigned long now = millis();
  unsigned long elapsed = now - experimentStart;

  if (!controllerEnabled && elapsed >= START_DELAY_MS) {
    controllerEnabled = true;
  }

  if (now - lastSample >= SAMPLE_MS) {
    float dt = (now - lastSample) / 1000.0;

    noInterrupts();
    long counts = encoderCount;
    encoderCount = 0;
    interrupts();

    float countsPerSecond = counts / dt;
    float measuredRPM = countsPerSecond * 60.0 / COUNTS_PER_OUTPUT_REV;

    float referenceRPM = 0.0;
    float errorRPM = 0.0;
    int pwmCommand = 0;

    if (controllerEnabled) {
      referenceRPM = REFERENCE_RPM;
      errorRPM = referenceRPM - measuredRPM;
      float control = KP * errorRPM;
      control = constrain(control, 0.0, 255.0);
      pwmCommand = (int)(control + 0.5);
      setMotorPWM(pwmCommand);
    } else {
      stopMotor();
    }

    float timeSeconds = elapsed / 1000.0;
    Serial.print(timeSeconds, 3);
    Serial.print(",");
    Serial.print(referenceRPM, 2);
    Serial.print(",");
    Serial.print(measuredRPM, 2);
    Serial.print(",");
    Serial.print(errorRPM, 2);
    Serial.print(",");
    Serial.println(pwmCommand);

    lastSample = now;
  }

  if (elapsed >= START_DELAY_MS + RUN_TIME_MS) {
    stopMotor();
    experimentRunning = false;
    controllerEnabled = false;
    Serial.println("END");
  }
}
