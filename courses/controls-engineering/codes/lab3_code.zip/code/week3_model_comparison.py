"""
ENGR 3303 - Week 3 Lab
Compare measured P control with the Week 2 first-order model.

Install packages:
    pip install pandas numpy matplotlib
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

Kmotor = 0.775     # RPM/PWM from Week 2
tau = 0.55         # seconds from Week 2
Kp = 3
R = 120            # RPM
filename = "P_Kp3.csv"

df = pd.read_csv(filename)
idx = df["Reference_RPM"] > 0
d = df.loc[idx].copy()

t = d["Time_s"].to_numpy(); t = t - t[0]
rpm_measured = d["RPM"].to_numpy()

dc_gain = (Kmotor * Kp) / (1 + Kmotor * Kp)
tau_cl = tau / (1 + Kmotor * Kp)
rpm_ideal = R * dc_gain * (1 - np.exp(-t / tau_cl))

ess_ideal = R / (1 + Kmotor * Kp)
print(f"Ideal steady-state error = {ess_ideal:.2f} RPM")
print(f"Ideal closed-loop time constant = {tau_cl:.3f} s")

plt.plot(t, rpm_measured, "o", markersize=4, label="Measured")
plt.plot(t, rpm_ideal, linewidth=1.8, label="Ideal first-order model")
plt.axhline(R, linestyle="--", label="Reference")
plt.grid(True); plt.xlabel("Time After Reference Step (s)"); plt.ylabel("Motor Speed (RPM)"); plt.title("Measured vs. Ideal P-Control Response"); plt.legend(); plt.tight_layout(); plt.show()
