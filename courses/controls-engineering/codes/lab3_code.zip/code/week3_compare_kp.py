"""
ENGR 3303 - Week 3 Lab
Compare three proportional-gain experiments.

Install packages:
    pip install pandas numpy matplotlib
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

files = ["P_Kp1.csv", "P_Kp3.csv", "P_Kp6.csv"]
kp_values = [1, 3, 6]

data = [pd.read_csv(f) for f in files]
summary = []

plt.figure()
for df, kp in zip(data, kp_values):
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()
    t = d["Time_s"].to_numpy(); t = t - t[0]
    rpm = d["RPM"].to_numpy(); pwm = d["PWM"].to_numpy()
    R = np.mean(d["Reference_RPM"].to_numpy())
    yss = np.mean(rpm[-min(15, len(rpm)):])
    ess = R - yss
    max_pwm = np.max(pwm)
    summary.append({"Kp": kp, "ReferenceRPM": R, "SteadyStateRPM": yss, "SteadyStateErrorRPM": ess, "MaxPWM": max_pwm})
    plt.plot(t, rpm, linewidth=1.5, label=f"Kp = {kp}")
plt.axhline(summary[0]["ReferenceRPM"], linestyle="--", label="Reference")
plt.grid(True); plt.xlabel("Time After Reference Step (s)"); plt.ylabel("Motor Speed (RPM)"); plt.title("Effect of Proportional Gain"); plt.legend(); plt.tight_layout()

plt.figure()
for df, kp in zip(data, kp_values):
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()
    t = d["Time_s"].to_numpy(); t = t - t[0]
    plt.plot(t, d["PWM"].to_numpy(), linewidth=1.5, label=f"Kp = {kp}")
plt.grid(True); plt.xlabel("Time After Reference Step (s)"); plt.ylabel("PWM Command"); plt.title("Controller Effort for Different Kp Values"); plt.ylim([0, 265]); plt.legend(); plt.tight_layout()

summary_df = pd.DataFrame(summary)
print(summary_df)
summary_df.to_csv("kp_summary.csv", index=False)
plt.show()
