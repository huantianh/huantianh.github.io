"""
ENGR 3303 - Week 3 Lab
Record P-controller data from Arduino.

Install packages:
    pip install pyserial pandas matplotlib
"""
import time
import pandas as pd
import matplotlib.pyplot as plt
import serial

PORT = "COM3"             # Change to your Arduino port
BAUD = 115200
FILENAME = "P_Kp1.csv"

rows = []

with serial.Serial(PORT, BAUD, timeout=3) as ser:
    time.sleep(2.0)
    ser.reset_input_buffer()
    print("Connected. Waiting for Arduino data...")
    started = False

    while True:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue
        if line == "START":
            started = True
            print("Recording started.")
            continue
        if line == "END":
            print("Recording finished.")
            break
        if not started or "time" in line.lower():
            continue
        parts = line.split(",")
        if len(parts) == 5:
            try:
                t, ref, rpm, err, pwm = map(float, parts)
            except ValueError:
                continue
            rows.append({"Time_s": t, "Reference_RPM": ref, "RPM": rpm, "Error_RPM": err, "PWM": pwm})
            print(f"t={t:5.2f}  ref={ref:6.1f}  rpm={rpm:6.1f}  err={err:6.1f}  pwm={pwm:3.0f}")

df = pd.DataFrame(rows)
df.to_csv(FILENAME, index=False)
print(f"Saved {FILENAME}")

plt.figure()
plt.plot(df["Time_s"], df["Reference_RPM"], "--", linewidth=1.5, label="Reference")
plt.plot(df["Time_s"], df["RPM"], linewidth=1.5, label="Measured RPM")
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("Speed (RPM)")
plt.title("Proportional Motor-Speed Control")
plt.legend()
plt.tight_layout()

plt.figure()
plt.plot(df["Time_s"], df["PWM"], linewidth=1.5)
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("PWM Command")
plt.title("Controller Output")
plt.ylim([0, 265])
plt.tight_layout()
plt.show()
