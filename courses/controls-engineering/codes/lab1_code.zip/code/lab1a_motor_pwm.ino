// ENGR 3303 - Week 1 Lab 1A
// Arduino + L298N + DC Motor
// Open-loop PWM motor test

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;

int pwmValue = 120;   // Change this: 80, 120, 160, 200, 255

void setup() {
  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  // Safe startup
  analogWrite(ENA, 0);

  // Forward direction
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  delay(1000);

  // Run motor
  analogWrite(ENA, pwmValue);
}

void loop() {
}
