import numpy as np
import matplotlib.pyplot as plt

pwm = np.array([80, 120, 160, 200, 255])
speed = np.array([0, 0, 0, 0, 0])  # replace with measured averages

plt.plot(pwm, speed, "o-", linewidth=1.5, markersize=7)
plt.xlabel("PWM command")
plt.ylabel("Encoder counts per second")
plt.title("Open-Loop DC Motor Characterization")
plt.grid(True)
plt.xlim([70, 265])
plt.show()
