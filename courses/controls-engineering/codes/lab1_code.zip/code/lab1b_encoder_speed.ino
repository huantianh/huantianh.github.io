// ENGR 3303 - Week 1 Lab 1B
// Encoder count-rate measurement

const int ENA = 9;
const int IN1 = 7;
const int IN2 = 8;

const int ENC_A = 2;
const int ENC_B = 3;

int pwmValue = 120;  // Test 80, 120, 160, 200, 255

volatile unsigned long encoderCount = 0;

unsigned long lastPrint = 0;
const unsigned long sampleTime = 1000;  // ms

void countPulse() {
  encoderCount++;
}

void setup() {
  Serial.begin(115200);

  pinMode(ENA, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);

  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(ENC_A),
                  countPulse, RISING);

  // Forward direction
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);

  // Start motor
  analogWrite(ENA, pwmValue);

  lastPrint = millis();
}

void loop() {
  unsigned long now = millis();

  if (now - lastPrint >= sampleTime) {
    noInterrupts();
    unsigned long counts = encoderCount;
    encoderCount = 0;
    interrupts();

    float dt = (now - lastPrint) / 1000.0;
    float countsPerSecond = counts / dt;

    Serial.print("PWM = ");
    Serial.print(pwmValue);
    Serial.print(", Encoder counts/s = ");
    Serial.println(countsPerSecond);

    lastPrint = now;
  }
}
