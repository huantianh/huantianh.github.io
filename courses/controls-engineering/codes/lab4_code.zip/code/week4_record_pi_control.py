"""
ENGR 3303 - Week 4 Lab
Record PI-controller data from Arduino.

Requires:
    pip install pyserial pandas matplotlib
"""

import time
import pandas as pd
import matplotlib.pyplot as plt
import serial

# ---------------- USER SETTINGS ----------------
PORT = "COM3"             # Change to your Arduino port
BAUD = 115200
FILENAME = "PI_Ki0p2.csv"
# ------------------------------------------------

rows = []

with serial.Serial(PORT, BAUD, timeout=3) as ser:
    time.sleep(2.0)       # Allow Arduino reset
    ser.reset_input_buffer()
    print("Connected. Sending START...")
    ser.write(b"START\n")

    print("Waiting for Arduino data...")

    started = False

    while True:
        line = ser.readline().decode(errors="ignore").strip()

        if not line:
            continue

        if line == "START":
            started = True
            print("Recording started.")
            continue

        if line == "END":
            print("Recording finished.")
            break

        if not started or "time" in line.lower():
            continue

        parts = line.split(",")

        if len(parts) == 6:
            try:
                t, ref, rpm, err, pwm, integral = map(float, parts)
            except ValueError:
                continue

            rows.append({
                "Time_s": t,
                "Reference_RPM": ref,
                "RPM": rpm,
                "Error_RPM": err,
                "PWM": pwm,
                "Integral": integral
            })

            print(f"t={t:5.2f}  ref={ref:6.1f}  rpm={rpm:6.1f}  "
                  f"err={err:6.1f}  pwm={pwm:3.0f}  I={integral:8.2f}")

if not rows:
    raise RuntimeError("No motor data were received. Check the serial port, close Serial Monitor, and try again.")

df = pd.DataFrame(rows)
df.to_csv(FILENAME, index=False)
print(f"Saved {FILENAME}")

plt.figure()
plt.plot(df["Time_s"], df["Reference_RPM"], "--", linewidth=1.5, label="Reference")
plt.plot(df["Time_s"], df["RPM"], linewidth=1.5, label="Measured RPM")
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("Speed (RPM)")
plt.title("PI Motor-Speed Control")
plt.legend(loc="center left", bbox_to_anchor=(1.02, 0.5))
plt.tight_layout()

plt.figure()
plt.plot(df["Time_s"], df["PWM"], linewidth=1.5)
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("PWM Command")
plt.title("Controller Output")
plt.ylim([0, 265])
plt.tight_layout()

plt.figure()
plt.plot(df["Time_s"], df["Integral"], linewidth=1.5)
plt.grid(True)
plt.xlabel("Time (s)")
plt.ylabel("Integral State")
plt.title("Integral State")
plt.tight_layout()

plt.show()
