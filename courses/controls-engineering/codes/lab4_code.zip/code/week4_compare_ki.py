"""
ENGR 3303 - Week 4 Lab
Compare multiple PI-controller tests.

Requires:
    pip install pandas numpy matplotlib
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------- USER SETTINGS ----------------
files = ["PI_Ki0.csv", "PI_Ki0p2.csv", "PI_Ki0p6.csv"]
ki_values = [0.0, 0.2, 0.6]
# ------------------------------------------------

data = [pd.read_csv(f) for f in files]
summary = []

plt.figure()
for df, ki in zip(data, ki_values):
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()

    t = d["Time_s"].to_numpy()
    t = t - t[0]

    rpm = d["RPM"].to_numpy()
    ref = d["Reference_RPM"].to_numpy()
    pwm = d["PWM"].to_numpy()

    R = np.mean(ref)
    yss = np.mean(rpm[-min(15, len(rpm)):])
    ess = R - yss
    ymax = np.max(rpm)
    overshoot = max(0.0, ymax - R)
    max_pwm = np.max(pwm)

    summary.append({
        "Ki": ki,
        "ReferenceRPM": R,
        "SteadyStateRPM": yss,
        "SteadyStateErrorRPM": ess,
        "OvershootRPM": overshoot,
        "MaxPWM": max_pwm
    })

    plt.plot(t, rpm, linewidth=1.5, label=f"Ki = {ki}")

plt.axhline(summary[0]["ReferenceRPM"], linestyle="--", label="Reference")
plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("Motor Speed (RPM)")
plt.title("Effect of Integral Gain")
plt.legend()
plt.tight_layout()

plt.figure()
for df, ki in zip(data, ki_values):
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()
    t = d["Time_s"].to_numpy()
    t = t - t[0]
    plt.plot(t, d["PWM"].to_numpy(), linewidth=1.5, label=f"Ki = {ki}")

plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("PWM Command")
plt.title("PWM for Different Ki Values")
plt.ylim([0, 265])
plt.legend()
plt.tight_layout()

plt.figure()
for df, ki in zip(data, ki_values):
    idx = df["Reference_RPM"] > 0
    d = df.loc[idx].copy()
    t = d["Time_s"].to_numpy()
    t = t - t[0]
    plt.plot(t, d["Integral"].to_numpy(), linewidth=1.5, label=f"Ki = {ki}")

plt.grid(True)
plt.xlabel("Time After Reference Step (s)")
plt.ylabel("Integral State")
plt.title("Integral State for Different Ki Values")
plt.legend()
plt.tight_layout()

summary_df = pd.DataFrame(summary)
print(summary_df)
summary_df.to_csv("pi_summary.csv", index=False)

plt.show()
